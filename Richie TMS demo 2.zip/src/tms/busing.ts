// Staff busing: routes, passenger rosters, trip generation, assignment, dispatch,
// completion (actual stop times and boarding outcomes) and cancellation.
// Every write goes through executeBusing(), which checks permissions, validates input,
// enforces the trip state machine and writes an audit entry.

import { audit, authorise, fail, isValidDate, makeId, norm, TIME_RE, type Actor, type CommandResult, type Errors } from "./service";
import { mayActOnTrip } from "./scope";
import {
  DIRECTIONS,
  PASSENGER_STATUSES,
  ROUTE_STATUSES,
  VEHICLE_STATUS_LABELS,
  type BoardingOutcome,
  type BoardingRecord,
  type BusRoute,
  type Database,
  type Direction,
  type Passenger,
  type PassengerStatus,
  type RouteStatus,
  type Trip,
} from "./types";

export const BUSING_COMMAND_TYPES = [
  "create_route",
  "update_route",
  "create_passenger",
  "update_passenger",
  "generate_trips",
  "assign_trip",
  "dispatch_trip",
  "start_trip",
  "record_trip_stop",
  "complete_trip",
  "cancel_trip",
] as const;

export interface StopInput {
  id?: string;
  name: string;
  scheduledTime: string;
}

export interface RouteInput {
  name: string;
  clientId: string;
  direction: Direction;
  shiftId: string;
  vehicleCategoryId: string;
  weekdays: number[];
  startDate: string;
  endDate: string;
  stops: StopInput[];
  status: RouteStatus;
}

export interface PassengerInput {
  fullName: string;
  employeeRef: string;
  phone: string;
  clientId: string;
  routeId: string;
  stopId: string;
  status: PassengerStatus;
}

export interface TripAssignInput {
  vehicleId: string;
  driverId: string;
}

export interface CompleteTripInput {
  stopTimes: { stopId: string; actualTime: string }[];
  boardings: { passengerId: string; outcome: BoardingOutcome }[];
}

export interface ProgressiveStopInput {
  stopId: string;
  actualTime: string;
  boardings: { passengerId: string; outcome: BoardingOutcome }[];
}

export type BusingCommand =
  | { type: "create_route"; input: RouteInput }
  | { type: "update_route"; id: string; input: RouteInput }
  | { type: "create_passenger"; input: PassengerInput }
  | { type: "update_passenger"; id: string; input: PassengerInput }
  | { type: "generate_trips"; routeId: string; fromDate: string; toDate: string }
  | { type: "assign_trip"; id: string; input: TripAssignInput }
  | { type: "dispatch_trip"; id: string }
  | { type: "start_trip"; id: string }
  | { type: "record_trip_stop"; id: string; input: ProgressiveStopInput }
  | { type: "complete_trip"; id: string; input?: CompleteTripInput }
  | { type: "cancel_trip"; id: string; reason: string };

export const MAX_GENERATE_DAYS = 62;

export function isBusingCommand(command: { type: string }): command is BusingCommand {
  return (BUSING_COMMAND_TYPES as readonly string[]).includes(command.type);
}

// ---------- time helpers ----------

export function toMinutes(hhmm: string): number {
  const [h, m] = hhmm.split(":").map(Number);
  return h * 60 + m;
}

const addDays = (ymd: string, days: number) => {
  const d = new Date(`${ymd}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
};

const weekdayOf = (ymd: string) => new Date(`${ymd}T00:00:00Z`).getUTCDay();

const inclusiveDays = (from: string, to: string) =>
  Math.round((Date.parse(`${to}T00:00:00Z`) - Date.parse(`${from}T00:00:00Z`)) / 86_400_000) + 1;

// A trip occupies the time from its route's first stop to its last stop on the service date.
export function tripWindow(route: BusRoute): [number, number] {
  return [toMinutes(route.stops[0].scheduledTime), toMinutes(route.stops[route.stops.length - 1].scheduledTime)];
}

// On time: every stop's actual time is no later than its scheduled time plus the threshold.
// Early arrivals count as on time.
export function tripOnTime(trip: Trip, route: BusRoute, thresholdMinutes: number): boolean {
  return trip.stopLogs.every((log) => {
    const stop = route.stops.find((s) => s.id === log.stopId);
    return !!stop && toMinutes(log.actualTime) - toMinutes(stop.scheduledTime) <= thresholdMinutes;
  });
}

// ---------- validators ----------

export function validateRoute(db: Database, input: RouteInput, excludeId?: string) {
  const errors: Errors = {};
  const name = input.name.trim();
  if (!name) errors.name = "Route name is required.";

  const client = db.clients.find((c) => c.id === input.clientId);
  if (!input.clientId) errors.clientId = "Select the client this route serves.";
  else if (!client) errors.clientId = "Unknown client.";
  else if (client.status !== "active") errors.clientId = "This client is inactive.";

  if (!DIRECTIONS.includes(input.direction)) errors.direction = "Select a direction.";
  if (input.shiftId && !db.settings.shifts.some((s) => s.id === input.shiftId)) errors.shiftId = "Unknown shift.";

  if (!input.vehicleCategoryId) errors.vehicleCategoryId = "Select a vehicle category.";
  else if (!db.settings.vehicleCategories.some((c) => c.id === input.vehicleCategoryId)) errors.vehicleCategoryId = "Unknown vehicle category.";

  const weekdays = [...new Set(input.weekdays)].sort((a, b) => a - b);
  if (weekdays.length === 0 || weekdays.some((d) => !Number.isInteger(d) || d < 0 || d > 6))
    errors.weekdays = "Select at least one operating day.";

  if (!isValidDate(input.startDate)) errors.startDate = "Enter the start date.";
  if (input.endDate && !isValidDate(input.endDate)) errors.endDate = "Enter a valid end date, or leave it blank.";
  else if (input.endDate && isValidDate(input.startDate) && input.endDate < input.startDate)
    errors.endDate = "End date cannot be before the start date.";

  if (!ROUTE_STATUSES.includes(input.status)) errors.status = "Invalid status.";

  const stops = input.stops.map((s) => ({ id: s.id || makeId(), name: s.name.trim(), scheduledTime: s.scheduledTime.trim() }));
  if (stops.length < 2) errors.stops = "A route needs at least two stops (a start and a destination).";
  const seen = new Set<string>();
  stops.forEach((s, i) => {
    if (!s.name) errors[`stops.${i}.name`] = "Stop name is required.";
    else if (seen.has(norm(s.name))) errors[`stops.${i}.name`] = "Duplicate stop name.";
    seen.add(norm(s.name));
    if (!TIME_RE.test(s.scheduledTime)) errors[`stops.${i}.scheduledTime`] = "Use HH:MM (24-hour).";
    else if (i > 0 && TIME_RE.test(stops[i - 1].scheduledTime) && s.scheduledTime < stops[i - 1].scheduledTime)
      errors[`stops.${i}.scheduledTime`] = "Times must not go backwards along the route.";
  });

  // Once trips exist, the stop list, client and vehicle category are locked so completed
  // trip records always point at stops that still exist.
  if (excludeId && db.trips.some((t) => t.routeId === excludeId)) {
    const existing = db.routes.find((r) => r.id === excludeId);
    const sameStops =
      !!existing &&
      existing.stops.length === stops.length &&
      existing.stops.every((s, i) => s.id === stops[i].id && s.name === stops[i].name && s.scheduledTime === stops[i].scheduledTime);
    if (existing && (!sameStops || existing.clientId !== input.clientId || existing.vehicleCategoryId !== input.vehicleCategoryId))
      errors.stops = "Stops, client and vehicle category are locked because trips already exist for this route. Create a new route instead.";
  }

  return {
    errors,
    value: {
      name,
      clientId: input.clientId,
      direction: input.direction,
      shiftId: input.shiftId || null,
      vehicleCategoryId: input.vehicleCategoryId,
      weekdays,
      startDate: input.startDate,
      endDate: input.endDate || null,
      stops,
      status: input.status,
    },
  };
}

export function validatePassenger(db: Database, input: PassengerInput, excludeId?: string) {
  const errors: Errors = {};
  const fullName = input.fullName.trim();
  if (!fullName) errors.fullName = "Full name is required.";

  const client = db.clients.find((c) => c.id === input.clientId);
  if (!input.clientId) errors.clientId = "Select the client.";
  else if (!client) errors.clientId = "Unknown client.";
  else if (client.status !== "active") errors.clientId = "This client is inactive.";

  const employeeRef = input.employeeRef.trim();
  if (employeeRef && db.passengers.some((p) => p.id !== excludeId && p.clientId === input.clientId && norm(p.employeeRef) === norm(employeeRef)))
    errors.employeeRef = "This employee reference already exists for this client.";

  if (!PASSENGER_STATUSES.includes(input.status)) errors.status = "Invalid status.";

  const routeId: string | null = input.routeId || null;
  const stopId: string | null = routeId ? input.stopId || null : null;
  if (routeId) {
    const route = db.routes.find((r) => r.id === routeId);
    if (!route) errors.routeId = "Unknown route.";
    else if (route.clientId !== input.clientId) errors.routeId = "This route belongs to a different client.";
    else if (route.status === "ended") errors.routeId = "This route has ended.";
    if (route && !errors.routeId) {
      if (!stopId) errors.stopId = "Select the pickup stop.";
      else if (!route.stops.some((s) => s.id === stopId)) errors.stopId = "This stop does not belong to the selected route.";
    }
  }

  return {
    errors,
    value: { fullName, clientId: input.clientId, employeeRef, phone: input.phone.trim(), routeId, stopId, status: input.status },
  };
}

// Phase 11: mid-trip passenger changes. Stops already recorded on any in-progress trip on
// the route are immutable; future stops may gain, lose, or move passengers.
function inProgressTripsForRoute(db: Database, routeId: string | null): Trip[] {
  if (!routeId) return [];
  return db.trips.filter((trip) => trip.routeId === routeId && trip.status === "in_progress");
}

// In-progress trips on this route that already recorded the given stop.
function tripsWithRecordedStop(trips: Trip[], stopId: string): Trip[] {
  return trips.filter((trip) => trip.stopLogs.some((log) => log.stopId === stopId));
}

// Field errors when a passenger edit would disturb an in-progress run, or {} when safe.
// A passenger with a boarding outcome on any in-progress trip keeps only personal-detail
// edits; otherwise the new effective assignment must be future on every in-progress trip.
function midTripPassengerErrors(
  db: Database,
  existing: Passenger,
  value: { routeId: string | null; stopId: string | null; status: PassengerStatus; clientId: string },
): Errors {
  const errors: Errors = {};
  const boardedTrips = db.trips.filter(
    (trip) => trip.status === "in_progress" && trip.boardings.some((record) => record.passengerId === existing.id),
  );
  if (boardedTrips.length > 0) {
    const refs = boardedTrips.map((trip) => trip.reference).join(", ");
    if (value.routeId !== existing.routeId) errors.routeId = `This passenger already boarded on ${refs}; the route cannot be changed mid-run.`;
    if (value.stopId !== existing.stopId) errors.stopId = `This passenger already boarded on ${refs}; the pickup stop cannot be changed mid-run.`;
    if (value.status !== existing.status) errors.status = `This passenger already has a boarding outcome on ${refs}; the status cannot be changed mid-run.`;
    if (value.clientId !== existing.clientId) errors.clientId = `This passenger already boarded on ${refs}; the client cannot be changed mid-run.`;
    return errors;
  }
  if (value.status === "active" && value.routeId && value.stopId) {
    const recorded = tripsWithRecordedStop(inProgressTripsForRoute(db, value.routeId), value.stopId);
    if (recorded.length > 0)
      errors.stopId = `That stop was already recorded on ${recorded.map((trip) => trip.reference).join(", ")}. Assign a stop the run has not reached yet.`;
  }
  return errors;
}

// Vehicle and driver checks for a trip, including same-day time overlaps and rental clashes.
function assessResources(db: Database, route: BusRoute, trip: Trip, vehicleId: string, driverId: string): Errors {
  const errors: Errors = {};

  const vehicle = db.vehicles.find((v) => v.id === vehicleId);
  if (!vehicleId) errors.vehicleId = "Select a vehicle.";
  else if (!vehicle) errors.vehicleId = "Unknown vehicle.";
  else if (vehicle.categoryId !== route.vehicleCategoryId) errors.vehicleId = "Vehicle category does not match the route.";
  else if (vehicle.status !== "available") errors.vehicleId = `Vehicle must be Available to be assigned (currently ${VEHICLE_STATUS_LABELS[vehicle.status].toLowerCase()}).`;

  const driver = db.drivers.find((d) => d.id === driverId);
  if (!driverId) errors.driverId = "Select a driver.";
  else if (!driver) errors.driverId = "Unknown driver.";
  else if (driver.status !== "active") errors.driverId = `Driver is ${driver.status} and cannot be assigned.`;
  else if (driver.licenceExpiry < trip.serviceDate) errors.driverId = "Driver's licence expires before the service date.";

  if (errors.vehicleId || errors.driverId) return errors;

  const [start, end] = tripWindow(route);
  for (const other of db.trips) {
    if (other.id === trip.id || other.serviceDate !== trip.serviceDate) continue;
    if (other.status !== "planned" && other.status !== "dispatched" && other.status !== "in_progress") continue;
    const otherRoute = db.routes.find((r) => r.id === other.routeId);
    if (!otherRoute) continue;
    const [oStart, oEnd] = tripWindow(otherRoute);
    if (!(start < oEnd && oStart < end)) continue; // back-to-back or separate runs are allowed
    if (other.vehicleId === vehicleId) errors.vehicleId = `Vehicle is already on ${other.reference} at an overlapping time that day.`;
    if (other.driverId === driverId) errors.driverId = `Driver is already on ${other.reference} at an overlapping time that day.`;
  }

  for (const rental of db.rentals) {
    if (rental.status !== "confirmed" && rental.status !== "in_progress") continue;
    if (trip.serviceDate < rental.startDate || trip.serviceDate > rental.endDate) continue;
    if (rental.assignedVehicleId === vehicleId) errors.vehicleId = `Vehicle is assigned to rental ${rental.reference} on this date.`;
    if (rental.assignedDriverId === driverId) errors.driverId = `Driver is assigned to rental ${rental.reference} on this date.`;
  }

  return errors;
}

// ---------- command execution ----------

export function executeBusing(db: Database, actor: Actor | null, command: BusingCommand, now: string = new Date().toISOString()): CommandResult {
  switch (command.type) {
    case "create_route": {
      const denied = authorise(actor, "routes:create");
      if (denied) return denied;
      const { errors, value } = validateRoute(db, command.input);
      if (Object.keys(errors).length) return fail("Please correct the highlighted fields.", errors);
      const created: BusRoute = {
        id: makeId(),
        reference: `RT-${String(db.routes.length + 1).padStart(3, "0")}`,
        ...value,
        createdAt: now,
        updatedAt: now,
      };
      const next = audit({ ...db, routes: [...db.routes, created] }, actor, {
        action: "routes:create",
        entity: "route",
        entityId: created.id,
        summary: `Route ${created.reference} created with ${created.stops.length} stops (${created.status}).`,
      }, now);
      return { ok: true, db: next, message: `Route ${created.reference} created.` };
    }

    case "update_route": {
      const denied = authorise(actor, "routes:update");
      if (denied) return denied;
      const existing = db.routes.find((r) => r.id === command.id);
      if (!existing) return fail("Route not found.");
      const { errors, value } = validateRoute(db, command.input, existing.id);
      if (Object.keys(errors).length) return fail("Please correct the highlighted fields.", errors);
      const updated: BusRoute = { ...existing, ...value, updatedAt: now };
      const next = audit({ ...db, routes: db.routes.map((r) => (r.id === updated.id ? updated : r)) }, actor, {
        action: "routes:update",
        entity: "route",
        entityId: updated.id,
        summary: `Route ${updated.reference} updated (${updated.status}).`,
      }, now);
      return { ok: true, db: next, message: `Route ${updated.reference} updated.` };
    }

    case "create_passenger": {
      const denied = authorise(actor, "passengers:create");
      if (denied) return denied;
      const { errors, value } = validatePassenger(db, command.input);
      if (Object.keys(errors).length) return fail("Please correct the highlighted fields.", errors);
      // A new active passenger may only join a stop still in the future on every
      // in-progress trip on the route. Inactive or unassigned records affect no run.
      if (value.status === "active" && value.routeId && value.stopId) {
        const recorded = tripsWithRecordedStop(inProgressTripsForRoute(db, value.routeId), value.stopId);
        if (recorded.length > 0)
          return fail(
            `That stop was already recorded on ${recorded.map((trip) => trip.reference).join(", ")}. New riders can only join a stop the run has not reached yet.`,
            { stopId: "This stop is already recorded on a run in progress." },
          );
      }
      const created: Passenger = { id: makeId(), ...value, createdAt: now, updatedAt: now };
      const running = inProgressTripsForRoute(db, value.routeId);
      const midTrip = running.length > 0 ? ` Mid-trip addition during ${running.map((trip) => trip.reference).join(", ")}.` : "";
      // Personal data is deliberately kept out of the audit summary.
      const next = audit({ ...db, passengers: [...db.passengers, created] }, actor, {
        action: "passengers:create",
        entity: "passenger",
        entityId: created.id,
        summary: `Passenger record created (${created.status}${created.routeId ? ", on a route" : ", no route"}).${midTrip}`,
      }, now);
      return { ok: true, db: next, message: "Passenger record created." };
    }

    case "update_passenger": {
      const denied = authorise(actor, "passengers:update");
      if (denied) return denied;
      const existing = db.passengers.find((p) => p.id === command.id);
      if (!existing) return fail("Passenger not found.");
      const { errors, value } = validatePassenger(db, command.input, existing.id);
      if (Object.keys(errors).length) return fail("Please correct the highlighted fields.", errors);
      const midTripErrors = midTripPassengerErrors(db, existing, value);
      if (Object.keys(midTripErrors).length)
        return fail("This change would disturb a run in progress. Only future stops can be changed mid-trip.", midTripErrors);
      const updated: Passenger = { ...existing, ...value, updatedAt: now };
      const affectedRefs = [...new Set([...inProgressTripsForRoute(db, existing.routeId), ...inProgressTripsForRoute(db, value.routeId)].map((trip) => trip.reference))];
      const midTrip = affectedRefs.length > 0 ? ` Mid-trip change during ${affectedRefs.join(", ")}.` : "";
      const next = audit({ ...db, passengers: db.passengers.map((p) => (p.id === updated.id ? updated : p)) }, actor, {
        action: "passengers:update",
        entity: "passenger",
        entityId: updated.id,
        summary: `Passenger record updated (${updated.status}).${midTrip}`,
      }, now);
      return { ok: true, db: next, message: "Passenger record updated." };
    }

    case "generate_trips": {
      const denied = authorise(actor, "trips:generate");
      if (denied) return denied;
      const route = db.routes.find((r) => r.id === command.routeId);
      if (!route) return fail("Route not found.");
      if (route.status !== "active") return fail(`Trips cannot be generated for a ${route.status} route.`);
      if (!isValidDate(command.fromDate) || !isValidDate(command.toDate))
        return fail("Enter a valid from and to date.", { fromDate: "Enter a valid date.", toDate: "Enter a valid date." });
      if (command.toDate < command.fromDate) return fail("The end date is before the start date.", { toDate: "Must be on or after the from date." });
      const span = inclusiveDays(command.fromDate, command.toDate);
      if (span > MAX_GENERATE_DAYS) return fail(`Generate at most ${MAX_GENERATE_DAYS} days at a time.`, { toDate: `Range is ${span} days. Generate at most ${MAX_GENERATE_DAYS} days at a time.` });

      const created: Trip[] = [];
      let counter = db.trips.length;
      for (let i = 0; i < span; i += 1) {
        const date = addDays(command.fromDate, i);
        if (date < route.startDate) continue;
        if (route.endDate && date > route.endDate) continue;
        if (!route.weekdays.includes(weekdayOf(date))) continue;
        if (db.trips.some((t) => t.routeId === route.id && t.serviceDate === date)) continue;
        counter += 1;
        created.push({
          id: makeId(),
          reference: `TR-${String(counter).padStart(4, "0")}`,
          routeId: route.id,
          serviceDate: date,
          status: "planned",
          vehicleId: null,
          driverId: null,
          dispatchedAt: null,
          startedAt: null,
          completedAt: null,
          cancelReason: null,
          stopLogs: [],
          boardings: [],
          onTimeThresholdMinutes: null,
          createdAt: now,
          updatedAt: now,
        });
      }
      if (created.length === 0)
        return fail(`No trips generated: ${route.reference} has no operating dates in this range, or trips already exist for them.`);
      const next = audit({ ...db, trips: [...db.trips, ...created] }, actor, {
        action: "trips:generate",
        entity: "route",
        entityId: route.id,
        summary: `${created.length} trip(s) generated for ${route.reference} (${command.fromDate} to ${command.toDate}).`,
      }, now);
      return { ok: true, db: next, message: `${created.length} trip(s) generated for ${route.reference}.` };
    }

    case "assign_trip": {
      const denied = authorise(actor, "trips:assign");
      if (denied) return denied;
      const existing = db.trips.find((t) => t.id === command.id);
      if (!existing) return fail("Trip not found.");
      if (existing.status !== "planned") return fail(`Only planned trips can be assigned (this trip is ${existing.status}).`);
      const route = db.routes.find((r) => r.id === existing.routeId);
      if (!route) return fail("Route not found.");
      const errors = assessResources(db, route, existing, command.input.vehicleId, command.input.driverId);
      if (Object.keys(errors).length) return fail("Assignment blocked. See the highlighted fields.", errors);
      const vehicle = db.vehicles.find((v) => v.id === command.input.vehicleId);
      const updated: Trip = { ...existing, vehicleId: command.input.vehicleId, driverId: command.input.driverId, updatedAt: now };
      const next = audit({ ...db, trips: db.trips.map((t) => (t.id === updated.id ? updated : t)) }, actor, {
        action: "trips:assign",
        entity: "trip",
        entityId: updated.id,
        summary: `${updated.reference} assigned vehicle ${vehicle?.registration ?? "-"} and a driver.`,
      }, now);
      return { ok: true, db: next, message: `${updated.reference} assigned.` };
    }

    case "dispatch_trip": {
      const denied = authorise(actor, "trips:dispatch");
      if (denied) return denied;
      const existing = db.trips.find((t) => t.id === command.id);
      if (!existing) return fail("Trip not found.");
      if (existing.status !== "planned") return fail(`Only planned trips can be dispatched (this trip is ${existing.status}).`);
      const route = db.routes.find((r) => r.id === existing.routeId);
      if (!route) return fail("Route not found.");
      if (route.status !== "active") return fail(`Route is ${route.status}; its trips cannot be dispatched.`);
      if (!existing.vehicleId || !existing.driverId) return fail("Assign a vehicle and a driver before dispatch.");
      const errors = assessResources(db, route, existing, existing.vehicleId, existing.driverId);
      if (Object.keys(errors).length) return fail("Dispatch blocked: the assigned resources are no longer valid.", errors);
      const updated: Trip = { ...existing, status: "dispatched", dispatchedAt: now, updatedAt: now };
      const next = audit({ ...db, trips: db.trips.map((t) => (t.id === updated.id ? updated : t)) }, actor, {
        action: "trips:dispatch",
        entity: "trip",
        entityId: updated.id,
        summary: `${updated.reference} dispatched.`,
      }, now);
      return { ok: true, db: next, message: `${updated.reference} dispatched.` };
    }

    case "start_trip": {
      const denied = authorise(actor, "trips:start");
      if (denied) return denied;
      const existing = db.trips.find((t) => t.id === command.id);
      if (!existing) return fail("Trip not found.");
      // Check ownership before status so a driver cannot probe another run.
      if (!mayActOnTrip(db, actor, existing.id)) return fail("You can only start a run assigned to you.");
      if (existing.status !== "dispatched") return fail(`Only a dispatched trip can be started (this trip is ${existing.status}).`);
      const route = db.routes.find((r) => r.id === existing.routeId);
      if (!route) return fail("Route not found.");
      if (route.status !== "active") return fail(`Route is ${route.status}; its trip cannot be started.`);
      if (!existing.vehicleId || !existing.driverId) return fail("The trip has no assigned vehicle and driver.");
      const errors = assessResources(db, route, existing, existing.vehicleId, existing.driverId);
      if (Object.keys(errors).length) return fail("Start blocked: the assigned resources are no longer valid.", errors);
      const updated: Trip = { ...existing, status: "in_progress", startedAt: now, updatedAt: now };
      const next = audit({ ...db, trips: db.trips.map((t) => (t.id === updated.id ? updated : t)) }, actor, {
        action: "trips:start",
        entity: "trip",
        entityId: updated.id,
        summary: `${updated.reference} started by its assigned driver.`,
      }, now);
      return { ok: true, db: next, message: `${updated.reference} started. Record each stop as you reach it.` };
    }

    case "record_trip_stop": {
      const denied = authorise(actor, "trips:record");
      if (denied) return denied;
      const existing = db.trips.find((t) => t.id === command.id);
      if (!existing) return fail("Trip not found.");
      // Own-record scope is checked before trip status (Q-42, no cross-run probing).
      if (!mayActOnTrip(db, actor, existing.id)) return fail("You can only record a stop on a run assigned to you.");
      if (existing.status !== "in_progress") return fail(`Stops can only be recorded while a trip is in progress (this trip is ${existing.status}).`);
      const route = db.routes.find((r) => r.id === existing.routeId);
      if (!route) return fail("Route not found.");
      const nextStop = route.stops[existing.stopLogs.length];
      if (!nextStop) return fail("All route stops are already recorded.");
      if (command.input.stopId !== nextStop.id)
        return fail("Stops must be recorded in route order.", { stopId: `The next stop is ${nextStop.name}.` });

      const errors: Errors = {};
      const actualTime = command.input.actualTime.trim();
      if (!TIME_RE.test(actualTime)) errors.actualTime = "Enter the actual arrival time (HH:MM).";
      const previousTime = existing.stopLogs[existing.stopLogs.length - 1]?.actualTime;
      if (TIME_RE.test(actualTime) && previousTime && actualTime < previousTime)
        errors.actualTime = `Actual time cannot go backwards from the previous stop (${previousTime}).`;

      const expected = db.passengers.filter((p) => p.routeId === route.id && p.stopId === nextStop.id && p.status === "active");
      const seen = new Set<string>();
      const newBoardings: BoardingRecord[] = [];
      for (const item of command.input.boardings) {
        const passenger = expected.find((p) => p.id === item.passengerId);
        if (!passenger) {
          errors.boardings = "A passenger is not on the active roster for this stop.";
          continue;
        }
        if (seen.has(passenger.id) || existing.boardings.some((record) => record.passengerId === passenger.id)) {
          errors.boardings = "A passenger can have only one outcome on a run.";
          continue;
        }
        if (item.outcome !== "boarded" && item.outcome !== "no_show") {
          errors.boardings = "Select boarded or did not board.";
          continue;
        }
        seen.add(passenger.id);
        newBoardings.push({ passengerId: passenger.id, stopId: nextStop.id, outcome: item.outcome });
      }
      if (!errors.boardings && seen.size !== expected.length)
        errors.boardings = `Record an outcome for every active passenger at ${nextStop.name} (${expected.length}).`;
      if (Object.keys(errors).length) return fail("This stop record is incomplete. See the highlighted fields.", errors);

      const updated: Trip = {
        ...existing,
        stopLogs: [...existing.stopLogs, { stopId: nextStop.id, actualTime }],
        boardings: [...existing.boardings, ...newBoardings],
        updatedAt: now,
      };
      const next = audit({ ...db, trips: db.trips.map((t) => (t.id === updated.id ? updated : t)) }, actor, {
        action: "trips:record_stop",
        entity: "trip",
        entityId: updated.id,
        // Do not put passenger names in the general audit log.
        summary: `${updated.reference}: ${nextStop.name} recorded at ${actualTime}; ${newBoardings.length} boarding outcome(s).`,
      }, now);
      return { ok: true, db: next, message: `${updated.reference}: ${nextStop.name} recorded.` };
    }

    case "complete_trip": {
      const denied = authorise(actor, "trips:complete");
      if (denied) return denied;
      const existing = db.trips.find((t) => t.id === command.id);
      if (!existing) return fail("Trip not found.");
      // Own-record scope is checked before anything else so a driver cannot learn
      // another run's state by probing it (D-25).
      if (!mayActOnTrip(db, actor, existing.id))
        return fail("You can only complete a run assigned to you.");
      if (existing.status !== "dispatched" && existing.status !== "in_progress")
        return fail(`Only a dispatched or in-progress trip can be completed (this trip is ${existing.status}).`);
      if (existing.status === "in_progress" && command.input)
        return fail("This run already has progressive stop records. Completion will use those records; they cannot be replaced here.");
      if (existing.status === "dispatched" && !command.input)
        return fail("No stop-by-stop records exist. Record the full completion or start the run first.");
      const route = db.routes.find((r) => r.id === existing.routeId);
      if (!route) return fail("Route not found.");

      const errors: Errors = {};
      const times = new Map<string, string>(existing.stopLogs.map((stop) => [stop.stopId, stop.actualTime]));
      if (command.input) {
        for (const stop of command.input.stopTimes) {
          if (!route.stops.some((routeStop) => routeStop.id === stop.stopId)) errors.stopTimes = "A stop does not belong to this route.";
          times.set(stop.stopId, stop.actualTime.trim());
        }
      }
      route.stops.forEach((s, i) => {
        if (!TIME_RE.test(times.get(s.id) ?? "")) errors[`stopTimes.${i}`] = "Enter the actual time at this stop (HH:MM).";
      });

      const roster = db.passengers.filter((p) => p.routeId === route.id && p.status === "active");
      const boardings: BoardingRecord[] = [...existing.boardings];
      const seen = new Set<string>();
      for (const b of command.input?.boardings ?? []) {
        const passenger = roster.find((p) => p.id === b.passengerId);
        if (!passenger) {
          errors.boardings = "A recorded passenger is not on this route's active roster.";
          continue;
        }
        if (seen.has(passenger.id) || boardings.some((record) => record.passengerId === passenger.id)) {
          errors.boardings = "A passenger has more than one outcome recorded.";
          continue;
        }
        if (b.outcome !== "boarded" && b.outcome !== "no_show") {
          errors.boardings = "Invalid boarding outcome.";
          continue;
        }
        seen.add(passenger.id);
        boardings.push({ passengerId: passenger.id, stopId: passenger.stopId ?? "", outcome: b.outcome });
      }
      if (!errors.boardings && boardings.length !== roster.length)
        errors.boardings = `Record an outcome for every active passenger on this route (${roster.length}).`;
      if (Object.keys(errors).length) return fail("The trip record is incomplete. See the highlighted fields.", errors);

      const threshold = db.settings.onTimeThresholdMinutes;
      const updated: Trip = {
        ...existing,
        status: "completed",
        stopLogs: route.stops.map((s) => ({ stopId: s.id, actualTime: times.get(s.id) ?? "" })),
        boardings,
        completedAt: now,
        onTimeThresholdMinutes: threshold,
        updatedAt: now,
      };
      const timing =
        threshold === null
          ? "On-time not computed: the threshold is not configured (Q-06)."
          : `On time: ${tripOnTime(updated, route, threshold) ? "yes" : "no"} (threshold ${threshold} min).`;
      const boarded = boardings.filter((b) => b.outcome === "boarded").length;
      const next = audit({ ...db, trips: db.trips.map((t) => (t.id === updated.id ? updated : t)) }, actor, {
        action: "trips:complete",
        entity: "trip",
        entityId: updated.id,
        summary: `${updated.reference} completed: ${boarded} boarded, ${boardings.length - boarded} no-show. ${timing}`,
      }, now);
      return { ok: true, db: next, message: `${updated.reference} completed. ${timing}` };
    }

    case "cancel_trip": {
      const denied = authorise(actor, "trips:cancel");
      if (denied) return denied;
      const existing = db.trips.find((t) => t.id === command.id);
      if (!existing) return fail("Trip not found.");
      if (existing.status !== "planned" && existing.status !== "dispatched")
        return fail(`A ${existing.status} trip cannot be cancelled.`);
      if (!command.reason.trim()) return fail("A reason is required.", { reason: "Give a short reason for cancelling this trip." });
      const updated: Trip = { ...existing, status: "cancelled", cancelReason: command.reason.trim(), updatedAt: now };
      const next = audit({ ...db, trips: db.trips.map((t) => (t.id === updated.id ? updated : t)) }, actor, {
        action: "trips:cancel",
        entity: "trip",
        entityId: updated.id,
        summary: `${updated.reference} cancelled. Reason: ${updated.cancelReason}`,
      }, now);
      return { ok: true, db: next, message: `${updated.reference} cancelled.` };
    }
  }
}
