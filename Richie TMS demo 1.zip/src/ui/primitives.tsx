import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode, SelectHTMLAttributes, TextareaHTMLAttributes } from "react";
import { cn } from "../utils/cn";
import type { Tone } from "../tms/useTms";

type ButtonVariant = "primary" | "secondary" | "ghost" | "danger";

export function Button({ variant = "secondary", className, ...props }: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: ButtonVariant }) {
  const styles: Record<ButtonVariant, string> = {
    primary: "rt-btn-primary",
    secondary: "",
    ghost: "rt-btn-ghost",
    danger: "rt-btn-danger",
  };
  return <button type="button" className={cn("rt-btn", styles[variant], className)} {...props} />;
}

export function Field({ label, hint, error, children, className }: { label: string; hint?: string; error?: string; children: ReactNode; className?: string }) {
  return (
    <label className={cn("rt-field", className)}>
      <span className="rt-field-label">{label}</span>
      {children}
      {hint && !error && <span className="rt-field-hint">{hint}</span>}
      {error && <span className="rt-field-err" role="alert">{error}</span>}
    </label>
  );
}

const inputBase = "rt-in";

export function TextInput({ invalid, className, ...props }: InputHTMLAttributes<HTMLInputElement> & { invalid?: boolean }) {
  return <input className={cn(inputBase, invalid && "rt-in-bad", className)} {...props} />;
}

export function TextArea({ invalid, className, ...props }: TextareaHTMLAttributes<HTMLTextAreaElement> & { invalid?: boolean }) {
  return <textarea className={cn(inputBase, invalid && "rt-in-bad", className)} {...props} />;
}

export function Select({ invalid, className, children, ...props }: SelectHTMLAttributes<HTMLSelectElement> & { invalid?: boolean }) {
  return (
    <select className={cn(inputBase, invalid && "rt-in-bad", className)} {...props}>
      {children}
    </select>
  );
}

const toneStyles: Record<Tone, string> = {
  info: "rt-notice-info",
  success: "rt-notice-success",
  warning: "rt-notice-warning",
  error: "rt-notice-error",
};

export function Notice({ tone = "info", title, children, className }: { tone?: Tone; title?: string; children: ReactNode; className?: string }) {
  return (
    <div className={cn("rt-notice", toneStyles[tone], className)} role={tone === "error" ? "alert" : "status"}>
      {title && <span className="rt-notice-title">{title}</span>}
      <span>{children}</span>
    </div>
  );
}

export function Badge({ tone = "info", children }: { tone?: Tone | "neutral"; children: ReactNode }) {
  const styles: Record<Tone | "neutral", string> = {
    neutral: "rt-badge-neutral",
    info: "rt-badge-info",
    success: "rt-badge-success",
    warning: "rt-badge-warning",
    error: "rt-badge-error",
  };
  return <span className={cn("rt-badge", styles[tone])}>{children}</span>;
}

export function PageHeader({ eyebrow, title, description, actions }: { eyebrow: string; title: string; description?: string; actions?: ReactNode }) {
  return (
    <div className="rt-pagehead">
      <div className="min-w-0">
        <p className="rt-eyebrow">{eyebrow}</p>
        <h1 className="rt-title">{title}</h1>
        {description && <p className="rt-desc">{description}</p>}
      </div>
      {actions && <div className="rt-pageactions">{actions}</div>}
    </div>
  );
}

export function Card({ title, description, actions, children, className }: { title?: string; description?: string; actions?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={cn("rt-card", className)}>
      {(title || actions) && (
        <header className="rt-card-head">
          <div className="min-w-0">
            {title && <h2 className="rt-card-title">{title}</h2>}
            {description && <p className="rt-card-desc">{description}</p>}
          </div>
          {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
        </header>
      )}
      <div className="rt-card-body">{children}</div>
    </section>
  );
}

export function EmptyState({ title, body, action }: { title: string; body: string; action?: ReactNode }) {
  return (
    <div className="rt-empty">
      <h3 className="rt-empty-title">{title}</h3>
      <p className="rt-empty-body">{body}</p>
      {action && <div className="mt-4 flex justify-center">{action}</div>}
    </div>
  );
}

export interface Column<T> {
  key: string;
  header: string;
  render: (row: T) => ReactNode;
  className?: string;
}

export function DataTable<T>({ columns, rows, rowKey, emptyState }: { columns: Column<T>[]; rows: T[]; rowKey: (row: T) => string; emptyState: ReactNode }) {
  if (rows.length === 0) return <>{emptyState}</>;
  return (
    <div className="rt-tablewrap">
      <table className="rt-table">
        <thead>
          <tr>
            {columns.map((c) => (
              <th key={c.key} className={cn(c.className)} scope="col">
                {c.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={rowKey(row)}>
              {columns.map((c) => (
                <td key={c.key} className={cn(c.className)}>
                  {c.render(row)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function Panel({ title, description, onClose, children }: { title: string; description?: string; onClose: () => void; children: ReactNode }) {
  return (
    <>
      <button type="button" className="rt-panel-scrim" aria-label="Close panel" onClick={onClose} />
      <div className="rt-panel" role="dialog" aria-modal="true" aria-label={title}>
        <header className="rt-panel-head">
          <div className="min-w-0">
            <h2 className="rt-panel-title">{title}</h2>
            {description && <p className="rt-panel-desc">{description}</p>}
          </div>
          <button type="button" onClick={onClose} aria-label="Close" className="rt-btn rt-btn-sm shrink-0 border-white/30 bg-transparent text-[#e8e4d6] hover:border-[#f2b01e] hover:text-[#f2b01e]">
            Close
          </button>
        </header>
        <div className="rt-panel-body">{children}</div>
      </div>
    </>
  );
}

export function Stat({ label, value, caption }: { label: string; value: string | number; caption?: string }) {
  return (
    <div className="rt-stat">
      <p className="rt-stat-label">{label}</p>
      <p className="rt-stat-value">{value}</p>
      {caption && <p className="rt-stat-cap">{caption}</p>}
    </div>
  );
}

export const formatDateTime = (iso: string) => new Date(iso).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
export const formatDate = (ymd: string) => {
  const d = new Date(`${ymd}T00:00:00`);
  return Number.isNaN(d.getTime()) ? ymd : d.toLocaleDateString(undefined, { dateStyle: "medium" });
};
export const todayYmd = () => new Date().toISOString().slice(0, 10);
