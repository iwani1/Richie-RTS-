import { useState } from "react";
import { BriefDesk } from "./docs/BriefDesk";
import { AuditPage } from "./pages/Audit";
import { SetupPage, SignInPage } from "./pages/Auth";
import { DashboardPage } from "./pages/Dashboard";
import { ClientsPage, DriversPage } from "./pages/Registers";
import { RentalsPage } from "./pages/Rentals";
import { StaffBusingPage } from "./pages/StaffBusing";
import { StaffLogisticsPage } from "./pages/StaffLogistics";
import { CompliancePage } from "./pages/Compliance";
import { FleetReadinessPage } from "./pages/FleetReadiness";
import { ClientPortalPage } from "./pages/ClientPortal";
import { DriverPortalPage } from "./pages/DriverPortal";
import { isRecordBound } from "./tms/permissions";
import { SettingsPage } from "./pages/Settings";
import { UsersPage } from "./pages/Users";
import { VehiclesPage } from "./pages/Vehicles";
import { NAV_ITEMS, type Route } from "./routes";
import { ROLE_LABELS } from "./tms/types";
import { TmsContext, useTms, useTmsState } from "./tms/useTms";
import { Notice } from "./ui/primitives";
import { cn } from "./utils/cn";

export default function App() {
  const tms = useTmsState();
  return (
    <TmsContext.Provider value={tms}>
      {tms.db.users.length === 0 ? <SetupPage /> : !tms.actor ? <SignInPage /> : <Shell />}
    </TmsContext.Provider>
  );
}

// Groups the rail into operations, records, then administration, so the nav reads like a
// dispatch desk rather than an undifferentiated link list.
const NAV_GROUPS: { caption: string; routes: Route[] }[] = [
  { caption: "Operations", routes: ["dashboard", "busing", "rentals", "logistics"] },
  { caption: "Fleet & compliance", routes: ["fleetReadiness", "compliance", "vehicles", "drivers"] },
  { caption: "Accounts", routes: ["clients", "users"] },
  { caption: "Governance", routes: ["settings", "audit", "documents"] },
];

const RAIL_NUM: Partial<Record<Route, string>> = {
  dashboard: "00", busing: "01", rentals: "02", logistics: "03",
  fleetReadiness: "04", compliance: "05", vehicles: "06", drivers: "07",
  clients: "08", users: "09", settings: "10", audit: "11",
};

function Shell() {
  const { db, actor, allowed, signOut, flash, setFlash, storageError } = useTms();
  // Record-bound roles (driver, client_contact) are confined to their own portal.
  // The internal screens read company-wide records, so those roles must not reach them.
  const portalRoute: Route | null =
    actor?.role === "driver" ? "driver_portal" : actor?.role === "client_contact" ? "client_portal" : null;
  const bound = actor ? isRecordBound(actor.role) : false;
  const [requestedRoute, setRoute] = useState<Route>(portalRoute ?? "dashboard");
  const [navOpen, setNavOpen] = useState(false);

  const items =
    bound && portalRoute
      ? NAV_ITEMS.filter((item) => item.route === portalRoute || item.route === "documents")
      : NAV_ITEMS.filter((item) => !item.permission || allowed(item.permission));

  // Derive the route actually shown during render, rather than correcting state after the
  // fact in an effect. The effect approach rendered the out-of-scope screen for one frame
  // before falling back; deriving it means a role never gets a single render of a screen
  // outside its scope (a defence-in-depth layer for own-record scope, see PERMISSIONS.md).
  const route: Route = items.some((i) => i.route === requestedRoute) ? requestedRoute : (portalRoute ?? "dashboard");

  const navigate = (next: Route) => {
    setRoute(next);
    setNavOpen(false);
    window.scrollTo({ top: 0 });
  };

  const currentLabel = items.find((i) => i.route === route)?.label ?? "";
  const groups =
    bound && portalRoute
      ? [{ caption: "Your access", routes: items.map((i) => i.route) }]
      : NAV_GROUPS.map((g) => ({ ...g, routes: g.routes.filter((r) => items.some((i) => i.route === r)) })).filter((g) => g.routes.length > 0);

  if (route === "documents") return <BriefDesk onExit={() => navigate("dashboard")} />;

  const page = (() => {
    switch (route) {
      case "rentals": return <RentalsPage navigate={navigate} />;
      case "busing": return <StaffBusingPage />;
      case "logistics": return <StaffLogisticsPage />;
      case "fleetReadiness": return <FleetReadinessPage />;
      case "compliance": return <CompliancePage />;
      case "driver_portal": return <DriverPortalPage />;
      case "client_portal": return <ClientPortalPage />;
      case "vehicles": return <VehiclesPage navigate={navigate} />;
      case "drivers": return <DriversPage />;
      case "clients": return <ClientsPage />;
      case "users": return <UsersPage />;
      case "settings": return <SettingsPage />;
      case "audit": return <AuditPage />;
      default: return <DashboardPage navigate={navigate} />;
    }
  })();

  return (
    <div className="rt-shell">
      {navOpen && <button type="button" className="rt-panel-scrim md:hidden" aria-label="Close navigation" onClick={() => setNavOpen(false)} />}

      <aside className={cn("rt-rail", navOpen && "rt-rail-open")} aria-label="Main navigation">
        <div className="rt-brand">
          <div className="rt-brand-mark" aria-hidden="true">R</div>
          <div className="min-w-0">
            <p className="rt-brand-name">RITCHIE TMS</p>
            <p className="rt-brand-sub truncate">{db.settings.companyName?.toUpperCase() ?? "Company name not set"}</p>
          </div>
        </div>

        <nav className="rt-nav">
          {groups.map((group) => (
            <div key={group.caption}>
              <p className="rt-nav-group">{group.caption}</p>
              {group.routes.map((r) => {
                const item = items.find((i) => i.route === r);
                if (!item) return null;
                const active = route === r;
                return (
                  <button
                    key={r}
                    type="button"
                    onClick={() => navigate(r)}
                    aria-current={active ? "page" : undefined}
                    className="rt-navitem"
                  >
                    <span className="rt-navnum" aria-hidden="true">{RAIL_NUM[r] ?? "--"}</span>
                    <span className="min-w-0">
                      <span className="rt-navlabel block truncate">{item.label}</span>
                      <span className="rt-navcaption block truncate">{item.caption}</span>
                    </span>
                  </button>
                );
              })}
            </div>
          ))}
        </nav>

        <div className="rt-railfoot">
          <p className="rt-railuser truncate">{actor?.fullName}</p>
          <p className="rt-railrole">{actor ? ROLE_LABELS[actor.role] : ""}</p>
          <button type="button" className="rt-railbtn" onClick={signOut}>Sign out</button>
        </div>
      </aside>

      <div className="rt-main">
        <header className="rt-topbar">
          <div className="flex min-w-0 items-center gap-3">
            <button type="button" className="rt-btn rt-btn-sm rt-mobonly" onClick={() => setNavOpen(true)} aria-label="Open navigation">Menu</button>
            <p className="rt-crumbs truncate">
              <span className="hidden sm:inline">Console</span>
              <span className="hidden sm:inline" aria-hidden="true">/</span>
              <b>{currentLabel}</b>
            </p>
          </div>
          <span
            className="rt-env"
            title="This build stores data in the browser. A server and PostgreSQL are not configured in this environment."
          >
            Browser-local · server not configured
          </span>
        </header>

        <main className="rt-content">
          {storageError && <Notice tone="error" className="mb-4">{storageError}</Notice>}
          {flash && (
            <div className="mb-4 flex items-start gap-2">
              <Notice tone={flash.tone} className="flex-1">{flash.message}</Notice>
              <button type="button" className="rt-btn rt-btn-sm" onClick={() => setFlash(null)} aria-label="Dismiss">Dismiss</button>
            </div>
          )}
          {page}
        </main>
      </div>
    </div>
  );
}
