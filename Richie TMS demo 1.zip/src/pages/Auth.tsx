import { useState, type FormEvent } from "react";
import { PASSWORD_MIN_LENGTH } from "../tms/service";
import { useTms } from "../tms/useTms";
import { Button, Field, Notice, TextInput } from "../ui/primitives";

// Split-screen entry: livery panel carrying the company identity and the integrity
// position, form on sand paper. Deliberately not a centred generic card.
function AuthFrame({ title, intro, children }: { title: string; intro: string; children: React.ReactNode }) {
  return (
    <div className="grid min-h-screen grid-cols-1 lg:grid-cols-[1fr_520px]">
      <section className="relative hidden flex-col justify-between overflow-hidden bg-[#0f2f26] p-10 lg:flex">
        <div className="flex items-center gap-3">
          <div className="rt-brand-mark" aria-hidden="true">R</div>
          <div>
            <p className="rt-brand-name">RITCHIE TMS</p>
            <p className="rt-brand-sub">Transport management · Ghana</p>
          </div>
        </div>

        <div className="relative max-w-lg">
          <p className="rt-eyebrow">Operations console</p>
          <p className="text-3xl font-bold leading-tight tracking-tight text-[#f4f1e6]">
            Staff busing.<br />Bus rentals.<br />Fleet logistics.
          </p>
          <p className="mt-5 text-sm leading-relaxed text-[#a8c3b8]">
            One record from a request, to planning, to an assigned vehicle and driver, to a
            completed run and its recorded cost.
          </p>
          <ul className="mt-8 space-y-2.5 text-xs text-[#c6d6ce]">
            {[
              "Every write is authorised, validated and audit-logged",
              "No prices, tax rates or policies are assumed",
              "Unknown rules stay unset until management decides",
            ].map((line) => (
              <li key={line} className="flex gap-2.5">
                <span className="mt-1.5 h-1.5 w-1.5 flex-none bg-[#f2b01e]" aria-hidden="true" />
                {line}
              </li>
            ))}
          </ul>
        </div>

        <p className="relative text-[10px] leading-relaxed text-[#7d968b]">
          Richie Transport Services · Accra, Ghana
        </p>
      </section>

      <section className="flex flex-col justify-center bg-[#f6f2e8] px-6 py-12 sm:px-12">
        <div className="mb-7 flex items-center gap-3 lg:hidden">
          <div className="rt-brand-mark" aria-hidden="true">R</div>
          <div>
            <p className="rt-brand-name text-[#0f2f26]">RITCHIE TMS</p>
            <p className="rt-brand-sub">Transport management · Ghana</p>
          </div>
        </div>

        <div className="w-full max-w-sm">
          <h1 className="text-2xl font-bold tracking-tight text-[#14110b]">{title}</h1>
          <p className="mt-2 text-sm leading-relaxed text-[#4a4436]">{intro}</p>
          <div className="mt-6 border-t border-[#ddd4c0] pt-6">{children}</div>
        </div>

        <p className="mt-10 max-w-sm text-[10px] leading-relaxed text-[#7a725f]">
          Data is stored in this browser's local storage. Server persistence is not configured in
          this environment.
        </p>
      </section>
    </div>
  );
}

export function SetupPage() {
  const { setupAdministrator } = useTms();
  const [values, setValues] = useState({ fullName: "", email: "", password: "", confirm: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [message, setMessage] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setMessage(null);
    if (values.password !== values.confirm) {
      setErrors({ confirm: "Passwords do not match." });
      return;
    }
    setBusy(true);
    const result = await setupAdministrator(values.fullName, values.email, values.password);
    setBusy(false);
    if (!result.ok) {
      setErrors(result.errors);
      setMessage(result.message);
    }
  };

  return (
    <AuthFrame title="Create the first administrator" intro="No user accounts exist yet. This account will own system settings and user management.">
      <form onSubmit={submit} className="space-y-4">
        {message && <Notice tone="error">{message}</Notice>}
        <Field label="Full name" error={errors.fullName}>
          <TextInput value={values.fullName} onChange={(e) => setValues({ ...values, fullName: e.target.value })} invalid={!!errors.fullName} autoComplete="name" required />
        </Field>
        <Field label="Email" error={errors.email}>
          <TextInput type="email" value={values.email} onChange={(e) => setValues({ ...values, email: e.target.value })} invalid={!!errors.email} autoComplete="username" required />
        </Field>
        <Field label="Password" hint={`At least ${PASSWORD_MIN_LENGTH} characters.`} error={errors.password}>
          <TextInput type="password" value={values.password} onChange={(e) => setValues({ ...values, password: e.target.value })} invalid={!!errors.password} autoComplete="new-password" required />
        </Field>
        <Field label="Confirm password" error={errors.confirm}>
          <TextInput type="password" value={values.confirm} onChange={(e) => setValues({ ...values, confirm: e.target.value })} invalid={!!errors.confirm} autoComplete="new-password" required />
        </Field>
        <Button type="submit" variant="primary" className="w-full py-2" disabled={busy}>
          {busy ? "Creating account..." : "Create administrator"}
        </Button>
      </form>
    </AuthFrame>
  );
}

export function SignInPage() {
  const { signIn } = useTms();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError(await signIn(email, password));
    setBusy(false);
  };

  return (
    <AuthFrame title="Sign in" intro="Use the account an administrator created for you.">
      <form onSubmit={submit} className="space-y-4">
        {error && <Notice tone="error">{error}</Notice>}
        <Field label="Email">
          <TextInput type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="username" required />
        </Field>
        <Field label="Password">
          <TextInput type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" required />
        </Field>
        <Button type="submit" variant="primary" className="w-full py-2" disabled={busy}>
          {busy ? "Checking..." : "Sign in"}
        </Button>
        <p className="text-[11px] text-stone-500">Forgotten passwords are reset by an administrator from the Users screen. Self-service reset is not available.</p>
      </form>
    </AuthFrame>
  );
}
